package uniandes.dpoo.aerolinea.modelo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {

	private String fecha;
	private Ruta ruta;
	private Avion avion;
	private HashMap<String, Tiquete> tiquetes;
	private static int contador = 1;
	
	public Vuelo(Ruta ruta,String fecha, Avion avion) {
		this.fecha = fecha;
		this.ruta = ruta;
		this.avion = avion;
		this.tiquetes = new HashMap<String,Tiquete>();
		
	}

	public String getFecha() {
		return fecha;
	}

	public Ruta getRuta() {
		return ruta;
	}

	public Avion getAvion() {
		return avion;
	}

	public HashMap<String,Tiquete> getTiquetes() {
		return tiquetes;
	}
	
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) {
		
	    int Total = 0;
	    for (int i = 0; i < cantidad; i++) {
	        int tarifa = calculadora.calcularTarifa(this, cliente);
	        Total += tarifa;
	        String id = "vuelo"+contador++;
	        Tiquete tiquete = new Tiquete(id, this, cliente, tarifa);
	        tiquetes.put(id, tiquete);
	    }

	    return Total;
	
	}

	public boolean equals(Object obj) {
		return avion.equals(obj);
	}

	
	
	
	
	
	
	
	
	
}
