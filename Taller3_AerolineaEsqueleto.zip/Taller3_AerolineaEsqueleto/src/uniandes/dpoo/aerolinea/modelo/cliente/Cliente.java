package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente {

	private List<Tiquete> tiquetesSinUsar;
	private List<Tiquete> tiquetesUsados;
	
	
	
	public Cliente() {
		this.tiquetesSinUsar = new ArrayList<Tiquete>();
		this.tiquetesUsados = new ArrayList<Tiquete>();
	}

	public abstract String getTipoCliente();
	
	public abstract String getIdentificador();
	
	public void agregarCliente(Tiquete tiquete) {
		tiquetesSinUsar.add(tiquete);
		
	}
	
	public int calcularValorTotalTiquetes() {
        int valorTotalTiquetes = 0;
        
        for (Tiquete cadaTiquete : tiquetesSinUsar) {
            valorTotalTiquetes += cadaTiquete.getTarifa();
        }
        
        for (Tiquete cadaTiquete : tiquetesUsados) {
            valorTotalTiquetes += cadaTiquete.getTarifa();
        }
        return valorTotalTiquetes;
	}
	
	public void usarTiquetes(Vuelo vuelo) {
        for (Tiquete tiquete : tiquetesSinUsar) {
            if (!tiquete.esUsado()) {
                tiquetesUsados.add(tiquete);
                tiquete.marcarComoUsado();
            }
        }
	}

	public List<Tiquete> getTiquetesSinUsar() {
		
		return this.tiquetesSinUsar;
	}
}
