package uniandes.dpoo.aerolinea.modelo.cliente;

public class ClienteNatural extends Cliente{
	
    private static final String NATURAL = "Natural";
    private  String nombre;
    private static int contador = 1;
    private String identificador; 
    
    
	public ClienteNatural(String nombre) {
		this.nombre = nombre;
		this.identificador = "natural" + contador++;
		
	}
	
	
	@Override
	public String getTipoCliente() {
		
		return NATURAL;
	}
	@Override
	public String getIdentificador() {
		
		return identificador;
	}

    
    
    
    


}
