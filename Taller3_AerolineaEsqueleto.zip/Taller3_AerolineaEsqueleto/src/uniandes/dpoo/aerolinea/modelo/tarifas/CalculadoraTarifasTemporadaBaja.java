package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas {

	public static final int COSTO_POR_KM_NATURAL = 600;
    public static final int COSTO_POR_KM_CORPORATIVO = 900;
    public static final double DESCUENTO_PEQ = 0.02;
    public static final double DESCUENTO_MEDIANAS = 0.1;
    public static final double DESCUENTO_GRANDES = 0.2;
    
    
    
    
	public CalculadoraTarifasTemporadaBaja() {
		super();
	}
	
	@Override
    protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
        Ruta laRuta = vuelo.getRuta();
        
        int distancia = super.calcularDistanciaVuelo(laRuta);
        
        if (cliente.getTipoCliente().equals("Corporativo")) {
            return distancia * COSTO_POR_KM_CORPORATIVO;
        } else {
            return distancia * COSTO_POR_KM_NATURAL;
        }
    }
	@Override
	protected double calcularPorcentajeDescuento(Cliente cliente) {
	    if (cliente.getTipoCliente().equals("Corporativo")) {
	        ClienteCorporativo clienteCorporativo = (ClienteCorporativo) cliente;
	        int tamanoEmpresa = clienteCorporativo.getTamañoEmpresa();

	        if (tamanoEmpresa == ClienteCorporativo.PEQUENA) {
	            return DESCUENTO_PEQ;
	        } else if (tamanoEmpresa == ClienteCorporativo.MEDIANA) {
	            return DESCUENTO_MEDIANAS;
	        } else if (tamanoEmpresa == ClienteCorporativo.GRANDE) {
	            return DESCUENTO_GRANDES;
	        }
	    }

	    return 0.0;
	}
}
